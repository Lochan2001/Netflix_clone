package com.example.netflix;

import android.widget.ImageView;

public interface MovieItemClickListener {

    void onMovieClick(Movie movie, ImageView movieImageView);
}
